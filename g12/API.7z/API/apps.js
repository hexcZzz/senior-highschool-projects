// Function to render the meals for search by name
function renderMealResultsByName(responses) {
  const container = document.getElementById("ingredients-container");
  container.classList.add("container");
  container.innerHTML = "";

  responses.forEach((response) => {
    const mealContainer = document.createElement("div");
    mealContainer.classList.add("meal");

    const linkUrl = document.createElement("a");
    linkUrl.classList.add("btn");
    linkUrl.textContent = "Watch Youtube";
    linkUrl.href = response.strYoutube;
    linkUrl.target = "_blank";

    const titleElement = document.createElement("a");
    titleElement.textContent = response.strMeal;
    titleElement.classList.add('title');
    titleElement.href = `meal.html?idMeal=${response.idMeal}`;  // Links to meal.html with meal ID
    titleElement.target = "_self";

    const categoryElement = document.createElement("p");
    categoryElement.textContent = response.strCategory;

    mealContainer.appendChild(titleElement);
    mealContainer.appendChild(categoryElement);
    mealContainer.appendChild(linkUrl);

    container.appendChild(mealContainer);
  });
}

// Function to search meals based on input value
function searchMeals() {
  const searchValue = document.getElementById('SearchName').value.trim();

  const container = document.getElementById('ingredients-container');
  if (searchValue) {
    // Check if the input is a number (meal ID)
    if (!isNaN(searchValue)) {
      fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${searchValue}`)
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => {
          if (data.meals) {
            renderMealResultsByName(data.meals);
          } else {
            container.innerHTML = '<p id="a">No meals found</p>';
          }
        })
        .catch(error => {
          console.error('Error fetching meals by ID:', error);
          container.innerHTML = '<p id="a">Error fetching meal by ID. Please check the ID and try again.</p>';
        });
    } else {
      // Search by meal name
      fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${searchValue}`)
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => {
          if (data.meals) {
            renderMealResultsByName(data.meals);
          } else {
            container.innerHTML = '<p id="a">No meals found</p>';
          }
        })
        .catch(error => {
          console.error('Error fetching meals by name:', error);
          container.innerHTML = '<p id="a">Error fetching meals. Please try again later.</p>';
        });
    }
  } else {
    container.innerHTML = '<p id="a">Please enter a meal name or ID</p>';
  }
}

// Event listener for input in the search box
document.getElementById('SearchName').addEventListener('input', searchMeals);