// Function to render meals with category
function renderMealResults(responses) {
  const container = document.getElementById("ingredients-container");
  container.classList.add("container");
  container.innerHTML = "";

  responses.forEach((response) => {
    const mealContainer = document.createElement("div");
    mealContainer.classList.add("meal");

    const linkUrl = document.createElement("a");
    linkUrl.classList.add("btn");
    linkUrl.textContent = "Watch Youtube";
    linkUrl.href = response.strYoutube;
    linkUrl.target = "_blank";

    const titleElement = document.createElement("a");
    titleElement.textContent = response.strMeal;
    titleElement.classList.add('title');
    titleElement.href = `meal.html?idMeal=${response.idMeal}`;
    titleElement.target = "_self";

    const categoryElement = document.createElement("p");
    categoryElement.textContent = response.strCategory || 'Unknown Category';

    mealContainer.appendChild(titleElement);
    mealContainer.appendChild(categoryElement);
    mealContainer.appendChild(linkUrl);

    container.appendChild(mealContainer);
  });
}

// Function to fetch meal details including category
function fetchMealDetails(meals) {
  const mealPromises = meals.map(meal =>
    fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`)
      .then(response => response.json())
      .then(data => {
        if (data.meals) {
          return data.meals[0]; // Return the detailed meal object
        }
      })
  );

  return Promise.all(mealPromises);
}

// Function to render meals based on first letter
function renderMealResultsByLetter(responses) {
  renderMealResults(responses);
}

// Function to render meals based on category
function renderMealResultsByCategory(responses) {
  renderMealResults(responses);
}

// Function to reset other dropdowns
function resetOtherDropdowns(except) {
  const dropdowns = ['letterSelect', 'categorySelect', 'areaSelect'];
  dropdowns.forEach(id => {
    if (id !== except) {
      const dropdown = document.getElementById(id);
      dropdown.selectedIndex = 0; // Reset to default
    }
  });
}

// Add event listener for letter dropdown
document.getElementById('letterSelect').addEventListener('change', function () {
  const letter = this.value;
  resetOtherDropdowns('letterSelect');

  if (letter) {
    fetch(`https://www.themealdb.com/api/json/v1/1/search.php?f=${letter}`)
      .then(response => response.json())
      .then(data => {
        if (data.meals) {
          renderMealResultsByLetter(data.meals);
        } else {
          document.getElementById('ingredients-container').innerHTML = '<p>No meals found</p>';
        }
      })
      .catch(() => {
        document.getElementById('ingredients-container').innerHTML = '<p>Error fetching meals</p>';
      });
  }
});

// Add event listener for category dropdown
document.getElementById('categorySelect').addEventListener('change', function () {
  const category = this.value;
  resetOtherDropdowns('categorySelect');

  if (category) {
    fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${category}`)
      .then(response => response.json())
      .then(data => {
        if (data.meals) {
          fetchMealDetails(data.meals)
            .then(detailedMeals => renderMealResults(detailedMeals));
        } else {
          document.getElementById('ingredients-container').innerHTML = '<p>No meals found in this category</p>';
        }
      })
      .catch(() => {
        document.getElementById('ingredients-container').innerHTML = '<p>Error fetching meals</p>';
      });
  }
});

// Add event listener for area dropdown
document.getElementById('areaSelect').addEventListener('change', function () {
  const area = this.value;
  resetOtherDropdowns('areaSelect');

  if (area) {
    fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?a=${area.charAt(0).toUpperCase() + area.slice(1)}`)
      .then(response => response.json())
      .then(data => {
        if (data.meals) {
          fetchMealDetails(data.meals)
            .then(detailedMeals => renderMealResults(detailedMeals));
        } else {
          document.getElementById('ingredients-container').innerHTML = '<p>No meals found in this area</p>';
        }
      })
      .catch(() => {
        document.getElementById('ingredients-container').innerHTML = '<p>Error fetching meals</p>';
      });
  }
});